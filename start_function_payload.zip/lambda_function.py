import boto3

# Initialize the EC2 client
ec2 = boto3.client('ec2')

def lambda_handler(event, context):
   
   # Handle the case where event is None
   if event is None:
       event = {
           "patchgroup_values": ["dummy-event-patchgroup_values"]
       }

   # Take input for PatchGroup tag values
   patchgroup_values = event.get('patchgroup_values')
   
   # Call describe_instances() method with filters
   response = ec2.describe_instances(Filters=[
       {
           'Name': 'tag:PatchGroup',
           'Values': patchgroup_values
       },
       {
          'Name': 'instance-state-name',
          'Values':['stopped']
       }
   ])

   # Extract instances from the response
   instances = []
   for reservation in response['Reservations']:
       for instance in reservation['Instances']:
           instances.append(instance['InstanceId'])
   
   print("Instances with tags 'PatchGroup' and values:", patchgroup_values)
   print(instances)
   
   # Start instances
   if instances:
       ec2.start_instances(InstanceIds=instances)
       print("Started instances:", instances)
   else:
       print("No instances found with the specified tags.")
   
   return instances

# Call the lambda_handler function
lambda_handler(None, None)
