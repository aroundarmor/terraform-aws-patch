import boto3

# Initialize the EC2 client
ec2 = boto3.client('ec2')

def remove_started_instance_tag(instances):
    if instances:
        for instance_id in instances:
            ec2.delete_tags(
                Resources=[instance_id],
                Tags=[{'Key': 'started_instance'}]
            )
        print("Tags removed from instances:", instances)
    else:
        print("No instances found to remove tags.")

def lambda_handler(event, context):
   
   # Handle the case where event is None
   if event is None:
       event = {
           "patchgroup_values": ["dummy-event-patchgroup_values"]
       }

   # Take input for PatchGroup tag values
   patchgroup_values = event.get('patchgroup_values')
   
   # Call describe_instances() method with filters
   response = ec2.describe_instances(Filters=[
       {
           'Name': 'tag:PatchGroup',
           'Values': patchgroup_values
       },
       {
          'Name': 'instance-state-name',
          'Values':['running']
       },
       {
           'Name': 'tag:started_instance',
           'Values': ['lambda']
       }
   ])

   # Extract instances from the response
   instances = []
   for reservation in response['Reservations']:
       for instance in reservation['Instances']:
           instances.append(instance['InstanceId'])
   
   print("Instances with tags 'PatchGroup' and values:", patchgroup_values)
   print(instances)
   
   # Stop instances
   if instances:
       ec2.stop_instances(InstanceIds=instances)
       print("Stopped instances:", instances)
       
       # Remove the tag 'started_instance' from instances
       remove_started_instance_tag(instances)
   else:
       print("No instances found with the specified tags or instances are not in running state.")
   
   return instances

# Call the lambda_handler function
lambda_handler(None, None)
